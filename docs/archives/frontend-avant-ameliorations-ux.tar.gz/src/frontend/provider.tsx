"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePathname, useRouter } from "next/navigation";
import { api, request } from "./api";
import { createDemo, executeDemo } from "./demo";
import {
  rolePermissions,
  type Permission,
  type Role,
  type Snapshot,
  type UserSession,
  type Sale,
} from "./types";
interface Workspace {
  snapshot: Snapshot | null;
  loading: boolean;
  error: string;
  demo: boolean;
  storeId: string;
  setStoreId: (id: string) => void;
  start: string;
  end: string;
  setDates: (start: string, end: string) => void;
  can: (permission: Permission) => boolean;
  command: (
    type: string,
    payload: Record<string, unknown>,
  ) => Promise<{ reference: string; sale?: Sale }>;
  reload: () => void;
  setRole: (role: Role) => void;
  href: (path: string) => string;
  notice: string;
  setNotice: (s: string) => void;
  setOrganization: (id: string) => void;
}
const Context = createContext<Workspace | null>(null);
export function useWorkspace() {
  const value = useContext(Context);
  if (!value) throw new Error("WorkspaceProvider requis");
  return value;
}
export const publicRoutes = [
  "/login",
  "/signup",
  "/forgot-password",
  "/invite/activate",
];
export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname(),
    router = useRouter(),
    demo = pathname === "/demo" || pathname.startsWith("/demo/"),
    isPublic = publicRoutes.includes(pathname);
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [storeId, setStore] = useState("s1"),
    [organizationId, setOrganizationId] = useState(""),
    [version, setVersion] = useState(0),
    [notice, setNotice] = useState("");
  const today = new Date().toISOString().slice(0, 10);
  const [start, setStart] = useState(today.slice(0, 7) + "-01"),
    [end, setEnd] = useState(today);
  const demoData = useRef<Snapshot | null>(null),
    pending = useRef(false),
    key = useRef<{ signature: string; value: string } | null>(null);
  useEffect(() => {
    const q = new URLSearchParams(location.search);
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.get("start") || ""))
      setStart(q.get("start")!);
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.get("end") || "")) setEnd(q.get("end")!);
  }, [pathname]);
  useEffect(() => {
    if (isPublic) {
      setLoading(false);
      setSnapshot(null);
      return;
    }
    setLoading(true);
    setError("");
    const abort = new AbortController();
    if (demo) {
      demoData.current ??= createDemo();
      setSnapshot(demoData.current);
      setLoading(false);
    } else {
      setSnapshot(null);
      api
        .snapshot(storeId, start, end, abort.signal, organizationId)
        .then((data) => {
          setSnapshot(data);
          if (
            !data.session.stores.some((s) => s.id === storeId) &&
            storeId !== "all"
          )
            setStore(data.session.defaultStoreId);
        })
        .catch((e) => {
          if (e.name !== "AbortError") setError(e.message);
        })
        .finally(() => {
          if (!abort.signal.aborted) setLoading(false);
        });
    }
    return () => abort.abort();
  }, [demo, isPublic, storeId, start, end, version, organizationId]);
  useEffect(() => {
    if (demo || isPublic) return;
    let active = true;
    const check = () => {
      if (document.visibilityState !== "visible") return;
      request<UserSession>("session")
        .then((session) => {
          if (!active) return;
          setSnapshot((previous) =>
            previous ? { ...previous, session } : previous,
          );
        })
        .catch((error) => {
          if (error.status === 403) {
            setSnapshot(null);
            setError(error.message);
          }
        });
    };
    const timer = setInterval(check, 60000);
    window.addEventListener("focus", check);
    return () => {
      active = false;
      clearInterval(timer);
      window.removeEventListener("focus", check);
    };
  }, [demo, isPublic]);
  const setStoreId = (id: string) => {
    if (!demo) setSnapshot(null);
    setStore(id);
    setNotice("");
  };
  const setDates = (a: string, b: string) => {
    if (a > b) return;
    setStart(a);
    setEnd(b);
    const q = new URLSearchParams(location.search);
    q.set("start", a);
    q.set("end", b);
    router.replace(`${pathname}?${q}`, { scroll: false });
  };
  const command = useCallback(
    async (type: string, payload: Record<string, unknown>) => {
      if (pending.current) throw new Error("Une opération est déjà en cours.");
      if (!navigator.onLine && !demo)
        throw new Error("Reconnectez-vous pour valider une opération.");
      if (storeId === "all")
        throw new Error("Choisissez une boutique pour cette opération.");
      pending.current = true;
      const signature = JSON.stringify({
        type,
        payload,
        storeId,
        organizationId,
      });
      if (key.current?.signature !== signature)
        key.current = { signature, value: crypto.randomUUID() };
      try {
        let reference = "";
        let sale: Sale | undefined;
        if (demo && demoData.current) {
          const result = executeDemo(demoData.current, {
            type,
            payload,
            storeId,
            idempotencyKey: key.current!.value,
          });
          demoData.current = result.snapshot;
          setSnapshot(result.snapshot);
          reference = result.reference;
          sale = result.snapshot.data.sales.find(
            (s) => s.reference === reference,
          );
        } else {
          const result = await api.command({
            type,
            payload: {
              ...payload,
              organizationId: snapshot?.session.organization.id,
            },
            storeId,
            idempotencyKey: key.current!.value,
          });
          reference = result.reference ?? "";
          sale = result.sale;
          setVersion((v) => v + 1);
        }
        key.current = null;
        setNotice(
          `Opération enregistrée${reference ? ` · ${reference}` : ""}${demo ? " en démonstration" : ""}.`,
        );
        return { reference, sale };
      } finally {
        pending.current = false;
      }
    },
    [demo, storeId, organizationId, snapshot?.session.organization.id],
  );
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(""), 6000);
    return () => clearTimeout(t);
  }, [notice]);
  const can = (p: Permission) =>
    snapshot?.session.permissions.includes(p) ?? false;
  const setRole = (role: Role) => {
    if (!demo || !demoData.current) return;
    demoData.current = {
      ...demoData.current,
      session: {
        ...demoData.current.session,
        user: { ...demoData.current.session.user, role },
        permissions: rolePermissions[role],
      },
    };
    setSnapshot(demoData.current);
    router.push(
      "/demo" +
        (role === "cashier"
          ? "/pos"
          : role === "stock"
            ? "/stock"
            : role === "accountant"
              ? "/accounting"
              : ""),
    );
  };
  return (
    <Context.Provider
      value={{
        snapshot,
        loading,
        error,
        demo,
        storeId,
        setStoreId,
        start,
        end,
        setDates,
        can,
        command,
        reload: () => setVersion((v) => v + 1),
        setRole,
        href: (path) => (demo ? `/demo${path === "/" ? "" : path}` : path),
        notice,
        setNotice,
        setOrganization: (id) => {
          setSnapshot(null);
          setOrganizationId(id);
          setStore("");
        },
      }}
    >
      {children}
    </Context.Provider>
  );
}
