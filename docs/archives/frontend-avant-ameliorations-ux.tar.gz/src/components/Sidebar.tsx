'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
    FiHome, FiPackage, FiShoppingCart, FiRepeat,
    FiDollarSign, FiX, FiShoppingBag, FiClock, FiBarChart2
} from 'react-icons/fi';

interface SidebarProps {
    isOpen: boolean;
    onClose: () => void;
}

const navItems = [
    { label: 'Tableau de bord', href: '/', icon: FiHome },
    { label: 'Stock & Inventaire', href: '/stock', icon: FiPackage },
    { label: 'Ventes', href: '/ventes', icon: FiShoppingCart },
    { label: 'Troc / Échanges', href: '/troc', icon: FiRepeat },
    { label: 'Rachat Clients', href: '/rachat', icon: FiShoppingBag },
    { label: 'Historique', href: '/historique', icon: FiClock },
    { label: 'Statistiques', href: '/statistiques', icon: FiBarChart2 },
    { label: 'Finance', href: '/finance', icon: FiDollarSign },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
    const pathname = usePathname();

    return (
        <>
            {/* Overlay: controlled purely by CSS on mobile */}
            <div
                className={`sidebar-overlay${isOpen ? ' visible' : ''}`}
                onClick={onClose}
            />
            <aside className={`sidebar${isOpen ? ' open' : ''}`}>
                <div className="sidebar-logo">
                    <div className="sidebar-logo-icon">V</div>
                    <span className="sidebar-logo-text">VORTEX</span>
                    <button
                        className="sidebar-close-btn"
                        onClick={onClose}
                        aria-label="Fermer le menu"
                    >
                        <FiX />
                    </button>
                </div>

                <nav className="sidebar-nav">
                    <span className="nav-section-label">Menu Principal</span>
                    {navItems.map((item) => {
                        const isActive = pathname === item.href ||
                            (item.href !== '/' && pathname.startsWith(item.href));
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={`nav-link${isActive ? ' active' : ''}`}
                                onClick={onClose}
                            >
                                <span className="nav-link-icon">
                                    <item.icon />
                                </span>
                                {item.label}
                            </Link>
                        );
                    })}
                </nav>

                <div style={{
                    padding: '16px 20px',
                    borderTop: '1px solid var(--border-primary)',
                    fontSize: '12px',
                    color: 'var(--text-muted)',
                }}>
                    VORTEX v1.0
                </div>
            </aside>
        </>
    );
}
